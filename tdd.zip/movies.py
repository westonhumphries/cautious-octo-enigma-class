import doctest

# FIXME: follow the steps in the Copilot SDLC flowchart to complete the code.
def read_file(filename, movie_titles, movie_years):
    '''
    Read the file and populate the movie_titles and movie_years lists
    >>> movie_titles = []
    >>> movie_years = []
    >>> read_file("movies.txt", movie_titles, movie_years)
    >>> len(movie_titles)
    964
    >>> len(movie_years)
    964
    '''
    with open(filename, 'r') as file:
        for line in file:
            line = line.strip()
            title, year = line.split(',')
            movie_titles.append(title)
            movie_years.append(year)

def display_movies(year, movie_titles, movie_years):
    '''
    Display the movies from the given year
    >>> movie_titles = []
    >>> movie_years = []
    >>> read_file("movies.txt", movie_titles, movie_years)
    >>> display_movies(1929, movie_titles, movie_years)
    Disraeli
    '''
    for i in range(len(movie_years)):
        if int(movie_years[i]) == year:
            print(movie_titles[i])

def main():

    movie_titles = []
    movie_years = []

    read_file("movies.txt", movie_titles, movie_years)

    while True:
        year_str = input("\nEnter the year to display or ['quit']: ")
        if year_str.startswith('q'):
            break
        if not year_str.isnumeric():
            print("invalid input")
            continue
        display_movies(int(year_str), movie_titles, movie_years)

#main()

doctest.testmod()